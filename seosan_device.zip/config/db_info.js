module.exports = (function () {
    return {
        local: { // localhost
            "host": "localhost",
            "user": "candh",
            "password": "candh123",
            "database": "candh"
        },
        real: { // localhost
            "host": "candh.ci1dwbaztoy8.ap-northeast-2.rds.amazonaws.com",
            "user": "candh",
            "password": "candh123",
            "database": "candh",
            "port": "3306"
        },
        dev: { // dev server db info
            host: 'localhost',
            user: 'candh',
            password: 'candh123',
            database: 'candh'
        }
    }
})();
