﻿'use strict';
var debug = require('debug');
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var app = express();
var dl = require('delivery'); // 파일 전송 모듈

//mysql db 연동
var mysql_dbc = require('./config/db')();
var pool = mysql_dbc.init();


var socket = require('socket.io-client')('http://52.79.160.29:5001'); //설정 및 촬영 소켓 모듈
//delivery 패키지 이용
var delivery = dl.listen(socket);
delivery.connect();
delivery.on('delivery.connect', function(delivery) {
    delivery.on('send.success', function(file) {
        console.log('File sent successfully!'+file);
            // 최근 접속 정보 저장
            pool.getConnection(function (err, connection)
            {            
                // Use the connection
                // 마지막으로 저장된 이미지 정보 가져오기
                connection.query(' select * from seosan_images  order by createdAt desc limit 0,1 ', function (err, row, fields) {
                    if(err) console.log(err);
                    
                    console.log(row);
                    //최근 연결되어 이미지를 보낸 데이터 가져오기
                    connection.query(' select * from seosan_networks where sn_serial = ? ', [row[0].si_serial], function (err, result, fields) {
                        if(err) console.log(err);
    
                        if ( result.length == 0 ) {
                            //등록된 정보가 없을시 새로 저장
                            connection.query(' insert into seosan_networks  (sn_serial, sn_type, createdAt) values ( ?, ?, NOW() )', [row[0].si_serial, 'car'], function (error, result) {
                                if(error) console.log(error);
                                if (!error) {
                                                                                
                                }
                                
                            });
                        }
    
                        if( result.length > 0 ){
                            //기존에 등록되어진 정보가 있을 시 업데이트
                            connection.query(' update seosan_networks  set createdAt = NOW() where sn_serial = ? ', [row[0].si_serial], function (error, result) {
                                if(error) console.log(error);
                                if (!error) {
                                                                                
                                }
                                
                            });
                        }

                    });
                    
                    connection.release();
                    
                });                
            });
    });
});

socket.on('connect', function () {
    console.log("connection");
    //최근 통신 데이터 
    pool.getConnection(function (err, connection)
    {            
        // sensor data check network
        connection.query(' select * from seosan_networks where sn_type = ? ', ['ard'], function (err, result, fields) {
            if(err) console.log(err);
            
            
            for(var i in result){
                //체크된 시간보다 큰 데이터 있으면 서버로 전송
                connection.query(' select sd_address, sd_serial, sd_data, date_format(createdAt,\'%Y%m%d%H%i%s\') as createdAt from seosan_data where sd_serial = ? and createdAt > ? ', [ result[i].sn_serial, result[i].createdAt ], function (err, rows, fields) {
                    
                    if(err) console.log(err);
                    if( rows.length > 0 ){
                        console.log('sensor_data_request :' + rows);
                        socket.emit('sensor_array_data_request', rows);    
                    }     
                });
            }
        });

        // camers data check network
        connection.query(' select * from seosan_networks where sn_type = ? ', ['car'], function (err, result, fields) {
            if(err) console.log(err);

            for(var i in result){
                //체크된 시간보다 큰 데이터 있으면 서버로 전송
                connection.query(' select * from seosan_images where si_serial = ? and createdAt > ? ', [ result[i].sn_serial, result[i].createdAt ], function (err, rows, fields) {
                    
                    if(err) console.log(err);

                    for(var i in rows){      
                        try {
                            // 촬영 이미지 전송
                            delivery.send({
                                name: rows[i].si_filename,
                                path: process.cwd() +'/images/'+ rows[i].si_path + "/" + rows[i].si_filename,
                                params: { serial: rows[i].si_serial, filename: rows[i].si_filename, path: rows[i].si_path, filesize: rows[i].si_filesize }
                            });
                        } catch (error) {
                            console.log(error);
                        }                  
                        

                        //setTimeout(function() { console.log('Works!'}, 3000);  //  3초 후 함수가 실행됨
                    }                    
                });
            }
        });        

        connection.release();

    });
});

socket.on('disconnect', function () {
    console.log("disconnection");
});


var routes = require('./routes/index')(pool);

var arduino = require('./routes/arduino')(pool,socket);

var camera = require('./routes/camera')(pool,socket,delivery).init();





// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

app.set('port', process.env.PORT || 3000);

var server = app.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
});
